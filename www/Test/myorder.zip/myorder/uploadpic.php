<?php  
    header("Access-Control-Allow-Origin: *");

    $new_image_name = $_POST["id"]. "_" . $_POST["nama"]."." . $_POST['ext'];
    //$new_image_name = "test".".jpg";    
    move_uploaded_file($_FILES["photo"]["tmp_name"], "images/".$new_image_name);

include "../connect.php";

$stmt="";
$halaman =$_POST['halaman'];

$id = $_POST["id"];
$ext = $_POST['ext'];

if($halaman == "menu")
{ 
  $sql = "UPDATE menu SET menu_img_ext= ? WHERE menu_id= ?";  
} 
else if($halaman == "jenispembayaran")
{
  $sql = "UPDATE payment SET payment_name = ? WHERE payment_id= ?";
}
else if($halaman == "kategori")
{
	$sql = "UPDATE category SET category_img_ext = ? WHERE category_id= ?";
}
else if($halaman == "banner")
{
	$sql = "UPDATE banner SET banner_img_ext = ? WHERE banner_id = ?"          
}

$stmt = $mysqli->prepare($sql);
$stmt->bind_param('si' ,$ext, $id);
$stmt->execute();
  

if ($stmt->affected_rows > 0) {       
	$arr_hasil = array("status"=>true,"pesan"=>"Berhasil Mengganti!");
	echo json_encode($arr_hasil);
} 
else {
	$arr_hasil = array("status"=>false,"pesan"=>"Gagal Mengganti!");
       echo json_encode($arr_hasil);
    die();
}

  
$stmt->close();
$mysqli->close();
?>
