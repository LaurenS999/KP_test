<?php
  include "../connect.php";

  $stmt="";
  $halaman =$_POST['halaman'];
  if($halaman == "cabang")
  {
      $id = $_POST['uid'];
      $storename = $_POST['storename'];
      $storeaddress = $_POST['storeaddress'];
      $store_phone = $_POST['store_phone'];
      $sql = "UPDATE store SET store_name = ?, store_address=?, store_phone = ? WHERE store_id= ?";
      $stmt = $mysqli->prepare($sql);
      $stmt->bind_param('ssii', $storename, $storeaddress, $store_phone, $id);
      $stmt->execute();      
  }

  else if($halaman == "menu")
  { 
      $id = $_POST['uid'];
      $nama = $_POST['nama'];
      $harga = $_POST['harga'];
      $diskon = $_POST['diskon'];
      $desc = $_POST['desc'];
      $idkategori = $_POST['idkategori'];
      $namakategori = $_POST['namakategori'];
      $idcabang = $_POST['idcabang'];

      $sql = "UPDATE menu SET
        menu_name= ? , 
        menu_sell_price= ? ,
        menu_discount= ?,
        menu_desc=?,
        category_id = ?, 
        store_id= ? 
        WHERE menu_id= ?";

      $stmt = $mysqli->prepare($sql);
      $stmt->bind_param('siisiii' ,$nama, $harga, $diskon, $desc  ,$idkategori, $idcabang, $id);
      $stmt->execute();
      
  } 

  else if($halaman == "jenispembayaran")
  {
      $id = $_POST['uid'];
      $jenispembayaran_nama = $_POST['jenispembayaran_nama'];
      

      $sql = "UPDATE payment
              SET payment_name = ? 
              WHERE payment_id= ?";
      $stmt = $mysqli->prepare($sql);
      $stmt->bind_param('si', $jenispembayaran_nama, $id);
      $stmt->execute();
  }
  else if($halaman == "karyawan")
  {
      $id = $_POST['uid'];
      $username = $_POST['username'];
      $user_name = $_POST['user_name'];
      $email = $_POST['email'];
      $user_phone = $_POST['user_phone'];
      
      $user_role = $_POST['user_role'];
      $store_id = $_POST['store_id'];
      
      // $id = 92;
      // $username = 'test';
      // $user_name = 'testttt';
      // $email = 'halo@gmail.com';
      // $user_phone = 123456789;      
      // $user_role = 'admin';
      // $store_id = '2';

      $sql = "UPDATE user SET uname = ?, user_name=?, email=?, user_phone=?,user_role=?, store_id=? WHERE user_id= ?";
      $stmt = $mysqli->prepare($sql);
      $stmt->bind_param('sssisii', $username, $user_name, $email, $user_phone, $user_role, $store_id, $id);
      $stmt->execute();
  }
  else if($halaman == "kategori")
  {
    $id = $_POST['uid'];
    $categoryname = $_POST['categoryname'];
    $sql = "UPDATE category SET category_name = ? WHERE category_id= ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('si', $categoryname, $id);
    $stmt->execute();
  }
  else if($halaman == "banner")
  {
      $id = $_POST['uid'];    
      $aim = $_POST['tipe_aim'];
      $aim_id = $_POST['aim_id'];
      $idcabang = $_POST['idcabang'];
      $tanggal = date("Y-m-d");

      if($aim == "kategori")
      {
          $sql = "UPDATE banner SET category_aim_id=?, menu_aim_id= null, banner_date_edited=?, store_id=?   WHERE banner_id = ?";          
      }
      else if($aim == "menu")
      {
          $sql = "UPDATE banner SET category_aim_id=null, menu_aim_id= ?, banner_date_edited=?, store_id=?   WHERE banner_id = ?";          
      }
      $stmt = $mysqli->prepare($sql);
      $stmt->bind_param('isii', $aim_id, $tanggal, $idcabang ,$id);
      $stmt->execute();
  }
    
  if ($stmt->affected_rows > 0) {       
 $arr_hasil = array("status"=>true,"pesan"=>"Berhasil Mengganti!");
 echo json_encode($arr_hasil);
  } 
  else {
    $arr_hasil = array("status"=>false,"pesan"=>"Gagal Mengganti!");
           echo json_encode($arr_hasil);
        die();
  }
  
  
$stmt->close();
$mysqli->close();
?>