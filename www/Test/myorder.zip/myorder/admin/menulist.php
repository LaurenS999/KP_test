<?php
  include "../connect.php";

  $storeid= $_POST['storeid'];
  //$storeid =1;
  if($storeid == "semuaresto")
  {
    $sql = "SELECT * FROM menu WHere menu_delete = 0";
  }
  else
  {
    $sql = "SELECT * FROM menu WHere menu_delete = 0 AND store_id=" . $storeid;      
  }
  $stmt = $mysqli->prepare($sql);  
  $stmt->execute();
  $result = $stmt->get_result(); 
  
  if ($result->num_rows > 0) {
	$menu = array();
    $i = 0;

    while ($row = $result->fetch_assoc()) {
	    $menu[$i]['menu_id'] = addslashes(htmlentities($row['menu_id']));
      $menu[$i]['menu_name'] = addslashes(htmlentities($row['menu_name']));   
      $menu[$i]['menu_desc'] = addslashes(htmlentities($row['menu_desc']));
      $menu[$i]['menu_sell_price'] = addslashes(htmlentities($row['menu_sell_price']));
      $menu[$i]['menu_discount'] = addslashes(htmlentities($row['menu_discount']));
	    $i++;
	}
	echo json_encode([
            'status' => true,
            'data' => $menu
        ]);
} 

else {
      echo json_encode([
            'status' => true,
            'data' => "Gagal Menemukan Menu"
        ]);
  die();
}
  	$stmt->close();
    $mysqli->close();
?>
