<?php
  include "../connect.php";
  
  $id = $_POST['uid'];  
  //$id = 92;

  $sql = "SELECT * from user where user_id = ". $id;
  $stmt = $mysqli->prepare($sql);
  $stmt->execute();
  $result = $stmt->get_result(); 
  
  if ($result->num_rows > 0) {
	$restodetail = array();
  $i = 0;

    while ($row = $result->fetch_assoc()) {
	    $restodetail[$i]['user_id'] = addslashes(htmlentities($row['user_id']));
      $restodetail[$i]['username'] = addslashes(htmlentities($row['uname']));
	    $restodetail[$i]['user_name'] = addslashes(htmlentities($row['user_name']));
      $restodetail[$i]['user_phone'] = addslashes(htmlentities($row['user_phone']));
      $restodetail[$i]['email'] = addslashes(htmlentities($row['email']));
      $restodetail[$i]['password'] = addslashes(htmlentities($row['password']));
      $restodetail[$i]['user_role'] = addslashes(htmlentities($row['user_role']));
      $restodetail[$i]['store_id'] = addslashes(htmlentities($row['store_id']));
      $i++;
	}
	echo json_encode(array('result' => 'Berhasil', 'data' => $restodetail));
}

else {
	echo json_encode(array('result' => $sql));
  die();
}
$stmt->close();
$mysqli->close();
?>
